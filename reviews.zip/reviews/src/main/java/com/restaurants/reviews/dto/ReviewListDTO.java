package com.restaurants.reviews.dto;

import com.restaurants.reviews.view.ReviewView;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ReviewListDTO {

    private Integer pageNo;
    private Boolean hasMore;
    private List<ReviewView> reviews;
}
