package com.restaurants.reviews.service;

import com.restaurants.reviews.consumers.restaurants.RestaurantConsumer;
import com.restaurants.reviews.dto.ReviewListDTO;
import com.restaurants.reviews.dto.SaveCommentDTO;
import com.restaurants.reviews.dto.UpdateCommentDTO;
import com.restaurants.reviews.dto.UpdateRestaurantRatingDTO;
import com.restaurants.reviews.exception.DataNotFoundException;
import com.restaurants.reviews.exception.InternalErrorException;
import com.restaurants.reviews.exception.BadRequestException;
import com.restaurants.reviews.model.Review;
import com.restaurants.reviews.repository.ReviewRepository;
import com.restaurants.reviews.view.ReviewView;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;

@Service
@AllArgsConstructor
@Slf4j
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final RestaurantConsumer restaurantConsumer;
    private final String REVIEW_SERVICE = "restaurantService";

    private KafkaTemplate<String, Object> template;
    @Value("{kafka.topic.review.name}")
    private String reviewTopic;

    //TODO: update stars in hotel service
    @Transactional
    public void saveComment(SaveCommentDTO saveComment, String userId){
        log.debug("Request to save comment for restaurant id: "+saveComment.getRestaurantId());
        try {
            Review review = new Review(null, saveComment.getRestaurantId(), userId,
                    saveComment.getStars(), saveComment.getComment(), LocalDate.now());
            updateRestaurantRating(review.getRestaurantId(), review.getStars());
            reviewRepository.save(review);
        }catch (Exception ex){
            log.error("Error occurred while saving comment", ex);
            throw new  ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Some error occurred while adding the comment . Pls... try again later");
        }
    }


    //TODO: update stars in hotel service check if same user is updating the review
    public void updateComment(Integer commentId, UpdateCommentDTO updateComment, String userId) {
        try {
            reviewRepository.findById(commentId)
                    .ifPresentOrElse(review -> {
                        if(!review.getUserId().equals(userId))
                            throw new BadRequestException("Sorry you don't have the right to edit the comment.");

                        updateRestaurantRating(review, updateComment);
                        review.setStars(updateComment.getStars());
                        review.setComment(updateComment.getComment());
                        reviewRepository.save(review);
                    }, ()->{
                        throw new DataNotFoundException("Sorry requested comment to update not found.");
                    });
        }catch (BadRequestException ex){
            log.error("User: "+userId+" has not right to edit the command as id does not match");
            throw new BadRequestException(ex.getMessage());
        }
        catch (DataNotFoundException ex){
            throw new DataNotFoundException(ex.getMessage());
        }catch (Exception ex){
            log.error("Some error occurred while updating comment for id: "+commentId, ex);
            throw new InternalErrorException("Some error occurred while updating comment. Pls try again later.");
        }

    }

    public void updateRestaurantRating(Review review, UpdateCommentDTO updateCommentDTO){
        if(review.getStars().equals(updateCommentDTO.getStars()))
            return;
        updateRestaurantRating(review.getRestaurantId(), updateCommentDTO.getStars());
    }

    public void updateRestaurantRating(Integer restaurantId, double rating){
        UpdateRestaurantRatingDTO updateRestaurantRating = new UpdateRestaurantRatingDTO(restaurantId, rating);
        template.send(reviewTopic, updateRestaurantRating);
    }
    public void deleteComment(Integer commentId, String userId) {

        if(!reviewRepository.existsById(commentId)){
            log.error("Comment with id "+commentId+" does not exist.");
            throw new DataNotFoundException("Comment not found.");
        }
        if(!reviewRepository.findById(commentId).get().getComment().equals(userId)){
            log.error("User: "+userId+" has not right to delete the command as user id does not match");
            throw new BadRequestException("Sorry you don't have the right to delete the comment.");
        }
        reviewRepository.deleteById(commentId);
    }


    public ReviewListDTO getReviewForRestaurant(Integer restaurantId, Integer pageNo) {

        log.debug("Searching review for restaurant: "+restaurantId+" at page no: "+pageNo);
        ReviewListDTO reviewList = new ReviewListDTO();
        reviewList.setPageNo(pageNo);
        Slice<ReviewView> reviewListForRestaurants = reviewRepository.findByRestaurantIdOrderByCreatedAtAsc(restaurantId,
                PageRequest.of(pageNo, 10));

        if(reviewListForRestaurants.hasContent()){
            reviewList.setHasMore(!reviewListForRestaurants.isLast());
            reviewList.setReviews(reviewListForRestaurants.getContent());
        }

        return reviewList;
    }
}
