package com.restaurants.reviews.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "reviews", indexes = {
        @Index(name = "idx_review_restaurantid", columnList = "restaurantId, userId")
})
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @Column(nullable = false, updatable = false)
    private Integer restaurantId;
    @Column(nullable = false, updatable = false)
    private String userId;
    @Column(nullable = false, precision = 2, scale = 1)
    private Double stars;
    @Column(nullable = false, length = 500, columnDefinition = "text")
    private String comment;
    @Column(updatable = false)
    private LocalDate createdAt = LocalDate.now();

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Review review = (Review) o;
        return id != null && Objects.equals(id, review.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "(" +
                "id = " + id + ", " +
                "restaurantId = " + restaurantId + ", " +
                "userId = " + userId + ", " +
                "stars = " + stars + ")";
    }


}
