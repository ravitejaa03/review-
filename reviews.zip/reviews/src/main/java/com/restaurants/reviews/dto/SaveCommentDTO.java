package com.restaurants.reviews.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class SaveCommentDTO {

    @Positive(message = "Restaurant id cannot be negative or zero")
    private Integer restaurantId;
    @Range(min = 0, max = 5, message = "Stars should be in range of 0.0 to 5.0")
    private Double stars;
    @Size(max = 500, message = "{validation.name.size.too_long}")
    @NotBlank(message = "Comment cannot be blank")
    private String comment;
}
