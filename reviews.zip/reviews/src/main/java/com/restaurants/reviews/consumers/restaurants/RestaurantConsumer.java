package com.restaurants.reviews.consumers.restaurants;

import org.hibernate.validator.constraints.Range;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@FeignClient(name="restaurants-service")
@RequestMapping("/api/v1/restaurant")
public interface RestaurantConsumer {

    @PutMapping("/{id}/rating")
     ResponseEntity<String> updateRatings(@NotNull(message = "Restaurant id cannot be null") @PathVariable("id") Integer restaurantId,
                                          @Range(min = 0, max = 5, message = "Stars should be in range of 0.0 to 5.0") @RequestParam("stars") Double stars);
}
