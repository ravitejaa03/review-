package com.restaurants.reviews.exception;

public class InternalErrorException extends RuntimeException{

   public InternalErrorException(String msg){
        super(msg);
    }
}
