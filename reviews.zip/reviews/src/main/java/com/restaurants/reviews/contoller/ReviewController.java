package com.restaurants.reviews.contoller;

import com.restaurants.reviews.consumers.restaurants.RestaurantConsumer;
import com.restaurants.reviews.dto.ReviewListDTO;
import com.restaurants.reviews.dto.SaveCommentDTO;
import com.restaurants.reviews.dto.UpdateCommentDTO;
import com.restaurants.reviews.service.ReviewService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@AllArgsConstructor
@Slf4j
@RequestMapping("/api/v1/review")
public class ReviewController {

    private final ReviewService reviewService;
    private final RestaurantConsumer restaurantConsumer;

    @PostMapping
    public ResponseEntity<String> saveComment(@Validated @RequestBody SaveCommentDTO saveComment,  Principal principal){
        log.debug("Request by user: "+getClaim("sub")+" to add comment: "+saveComment);
        String userId = (String) getClaim("uid");
        reviewService.saveComment(saveComment, userId);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Comment added for the restaurant.");
    }


    @GetMapping("/restaurant/{id}")
    public ResponseEntity<ReviewListDTO> getReviewForRestaurant(@PathVariable("id") Integer restaurantId,
                                       @RequestParam(value = "pageNo", defaultValue = "0") Integer pageNo){
        log.debug("Request to get comment for restaurant id: "+restaurantId+" at page no: "+pageNo);
        ReviewListDTO reviewForRestaurant = reviewService.getReviewForRestaurant(restaurantId, pageNo);
        log.debug("Total "+reviewForRestaurant.getReviews().size()+" reviews fetched for restaurant id: "+restaurantId);
        return ResponseEntity.ok(reviewForRestaurant);
    }

    @PatchMapping("/{commentId}")
    public ResponseEntity<String> updateComment(@PathVariable("commentId") Integer commentId,
                                                @RequestBody UpdateCommentDTO updateComment, Principal principal){
        log.debug("Request by user: "+getClaim("sub")+" to update comment with id "+commentId);
        String userId = (String) getClaim("uid");
        reviewService.updateComment(commentId, updateComment, userId);
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body("Comment updated successfully.");
    }

    @DeleteMapping("/{commentId}")
    public ResponseEntity<String> deleteComment(@PathVariable("commentId") Integer commentId){
        log.debug("Request by user: "+getClaim("sub")+" to delete comment with id "+commentId);
        String userId = (String) getClaim("uid");
        reviewService.deleteComment(commentId, userId);
        log.error("Deleted comment "+commentId+" by user "+userId);
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body("Comment deleted successfully.");
    }


    private static Object getClaim(String claim){
        Object principal = SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        Jwt jwt = (Jwt) principal;
//        UUID clubId = UUID.fromString(
        if(jwt.getClaims().containsKey(claim))
            return jwt.getClaim(claim);
        return null;
    }
}
