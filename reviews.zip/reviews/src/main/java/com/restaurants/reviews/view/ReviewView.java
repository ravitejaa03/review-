package com.restaurants.reviews.view;

import java.time.LocalDate;

public interface ReviewView {
    Integer getId();
    Double getStars();
    String getComment();
    LocalDate getCreatedAt();
}
