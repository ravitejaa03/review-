package com.restaurants.reviews.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Min;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdateRestaurantRatingDTO {

    @Min(value = 1)
    private Integer restaurantId;
    @Range(min = 0, max = 5)
    private double rating;
}
