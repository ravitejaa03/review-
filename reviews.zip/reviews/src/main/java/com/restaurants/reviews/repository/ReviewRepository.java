package com.restaurants.reviews.repository;

import com.restaurants.reviews.model.Review;
import com.restaurants.reviews.view.ReviewView;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Integer> {

    Slice<List<Review>> findByUserId(Integer userId, Pageable pageable);

    Slice<Review> findByRestaurantIdOrderByIdAsc(Integer restaurantId, Pageable pageable);

    Slice<ReviewView> findByRestaurantIdOrderByCreatedAtAsc(Integer restaurantId, Pageable pageable);

    Slice<ReviewView> getByRestaurantIdOrderByCreatedAtAsc(Integer restaurantId, Pageable pageable);






}
