package com.restaurants.reviews.view;

import javax.persistence.Column;
import java.time.LocalDate;

public interface ReviewAndUserIdView {

}
